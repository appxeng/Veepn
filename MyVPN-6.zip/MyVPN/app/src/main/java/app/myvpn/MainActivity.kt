package app.myvpn

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var store: Store
    private lateinit var adapter: ArrayAdapter<String>
    private var servers: List<Server> = emptyList()   // همهٔ سرورها (اشیای پایدار برای ثبت پینگ)
    private var shown: List<Server> = emptyList()     // ترتیب نمایش داده‌شده در لیست
    private lateinit var status: TextView
    private lateinit var target: TargetView
    private lateinit var waves: WaveOverlay
    private lateinit var btnConnect: KeyButton
    private lateinit var btnPing: KeyButton
    private lateinit var btnFree: KeyButton
    private lateinit var progressBox: View
    private lateinit var progressBar: ProgressBar
    private lateinit var progressLabel: TextView
    private lateinit var progressPct: TextView
    private var pendingLink: String? = null
    private var phase = 0            // 0 قطع · 1 در حال اتصال · 2 وصل · 3 ناموفق
    private var busy = false
    private var taps = 0
    private var lastTap = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        L.lang = store.lang
        setContentView(R.layout.activity_main)
        findViewById<View>(R.id.root).layoutDirection =
            if (L.isFa) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR

        status = findViewById(R.id.status)
        target = findViewById(R.id.target)
        waves = findViewById(R.id.waves)
        btnConnect = findViewById(R.id.btnConnect)
        btnPing = findViewById(R.id.btnPing)
        btnFree = findViewById(R.id.btnFree)
        progressBox = findViewById(R.id.progressBox)
        progressBar = findViewById(R.id.progressBar)
        progressLabel = findViewById(R.id.progressLabel)
        progressPct = findViewById(R.id.progressPct)

        adapter = ArrayAdapter(this, R.layout.item_server, mutableListOf())
        findViewById<ListView>(R.id.list).apply {
            adapter = this@MainActivity.adapter
            emptyView = null
            setOnItemClickListener { _, _, pos, _ -> shown.getOrNull(pos)?.let { connect(it.link) } }
        }

        findViewById<TextView>(R.id.subtitle).text = L.t("sub")
        btnConnect.text = L.t("connect")
        btnPing.text = L.t("ping")
        findViewById<KeyButton>(R.id.btnAdd).text = L.t("add")
        findViewById<KeyButton>(R.id.btnClear).text = L.t("clear")
        btnFree.text = L.t("free")
        findViewById<KeyButton>(R.id.btnSettings).text = L.t("settings")
        findViewById<KeyButton>(R.id.btnLang).apply {
            text = L.t("lang")
            setOnClickListener { store.lang = if (L.isFa) "en" else "fa"; recreate() }
        }

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)

        btnConnect.setOnClickListener {
            if (phase == 0 || phase == 3) connect(null) else disconnect()
        }
        btnPing.setOnClickListener { pingAll() }
        findViewById<KeyButton>(R.id.btnAdd).setOnClickListener { addDialog() }
        findViewById<KeyButton>(R.id.btnClear).setOnClickListener {
            store.links = emptyList(); store.freeLinks = emptyList(); reload()
        }
        findViewById<KeyButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        btnFree.setOnClickListener { findFree() }

        // چهار ضربهٔ پشت‌سرهم روی نام سازنده → موج وای‌فای از چهار طرف
        findViewById<View>(R.id.credit).setOnClickListener {
            val now = SystemClock.uptimeMillis()
            taps = if (now - lastTap < 900) taps + 1 else 1
            lastTap = now
            if (taps >= 4) { taps = 0; waves.play() }
        }

        MyVpnService.onState = { text -> status.text = text }
        MyVpnService.onPhase = { p -> applyPhase(p, animate = true) }
        reload()
        syncFromService()
        // اتصال خودکار هنگام باز شدن اپ اگر کاربر آخرین بار وصل بوده
        if (store.wantConnected && !MyVpnService.running && MyVpnService.lastPhase == 0) connect(null)
    }

    override fun onResume() {
        super.onResume()
        reload()
        syncFromService()
    }

    /** وضعیت واقعی سرویس را بدون انیمیشن نشان می‌دهد */
    private fun syncFromService() {
        val p = when {
            MyVpnService.running -> 2
            MyVpnService.lastPhase == 1 -> 1
            else -> 0
        }
        status.text = if (MyVpnService.lastState.isNotEmpty() && p != 0) MyVpnService.lastState else L.t("off")
        phase = p
        target.snap(when (p) { 2 -> TargetView.S.CONNECTED; 1 -> TargetView.S.CONNECTING; else -> TargetView.S.IDLE })
        updateConnectButton()
    }

    private fun applyPhase(p: Int, animate: Boolean) {
        phase = p
        if (animate) target.setState(when (p) {
            2 -> TargetView.S.CONNECTED
            1 -> TargetView.S.CONNECTING
            3 -> TargetView.S.MISSED
            else -> TargetView.S.IDLE
        })
        updateConnectButton()
    }

    private fun updateConnectButton() {
        btnConnect.danger = phase == 2 || phase == 1
        btnConnect.primary = !btnConnect.danger
        btnConnect.text = when (phase) {
            2 -> L.t("disconnect")
            1 -> L.t("connecting")
            else -> L.t("connect")
        }
        // لمس دکمه در حال اتصال = انصراف
    }

    // ───────────── لیست ─────────────

    /** لیست را از حافظه می‌خواند و پینگ‌های قبلی را حفظ می‌کند */
    private fun reload() {
        val old = servers.associateBy { it.link }
        servers = store.servers().onEach { n -> old[n.link]?.let { n.pingMs = it.pingMs } }
        render()
    }

    /** فقط نمایش؛ اشیای servers را دست نمی‌زند */
    private fun render() {
        shown = Pinger.sorted(servers)
        adapter.clear()
        adapter.addAll(shown.map {
            val p = when { it.pingMs > 0 -> "${it.pingMs} ms"; it.pingMs == 0L -> "…"; else -> "—" }
            val tag = if (it.free) "🆓 " else ""
            L.digits("$tag${it.name}   [$p]")
        })
        if (shown.isEmpty() && !busy) status.text = L.t("empty")
    }

    private fun showProgress(pct: Int, label: String) {
        busy = true
        progressBox.visibility = View.VISIBLE
        progressBar.progress = pct
        progressLabel.text = label
        progressPct.text = L.digits("$pct%")
    }

    private fun hideProgress() {
        busy = false
        progressBox.visibility = View.GONE
    }

    // ───────────── اتصال ─────────────

    private fun connect(link: String?) {
        pendingLink = link
        val prep = VpnService.prepare(this)
        if (prep != null) startActivityForResult(prep, 100) else startVpn(link)
    }

    private fun startVpn(link: String?) {
        val i = Intent(this, MyVpnService::class.java).setAction(MyVpnService.ACTION_START)
        link?.let { i.putExtra(MyVpnService.EXTRA_LINK, it) }
        startForegroundService(i)
        status.text = L.t("s_connecting")
        applyPhase(1, animate = true)
    }

    private fun disconnect() {
        startService(Intent(this, MyVpnService::class.java).setAction(MyVpnService.ACTION_STOP))
        applyPhase(0, animate = true)
        status.text = L.t("off")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) startVpn(pendingLink)
    }

    private fun pingAll() {
        if (busy) return
        servers.forEach { it.pingMs = 0 }
        render()
        val total = servers.size.coerceAtLeast(1)
        var done = 0
        showProgress(0, L.t("p_ping"))
        lifecycleScope.launch {
            Pinger.testAll(servers) {
                done++
                showProgress(done * 100 / total, L.t("p_ping"))
                render()
            }
            render()
            hideProgress()
            status.text = Pinger.nativeProblem()?.let { L.t("core_missing", it) }
                ?: Pinger.best(servers)?.let { L.t("best", it.name, it.pingMs) }
                ?: L.t("none_resp")
        }
    }

    private fun findFree() {
        if (busy) return
        btnFree.isEnabled = false
        showProgress(0, L.t("p_free_dl"))
        lifecycleScope.launch {
            val n = FreeServers.refresh(store, onProgress = { status.text = it }, onPercent = { pct ->
                showProgress(pct, if (pct < 30) L.t("p_free_dl") else L.t("p_free_test"))
            })
            reload()
            hideProgress()
            status.text = if (n > 0) L.t("free_added", n) else (Pinger.nativeProblem()?.let { L.t("core_missing", it) } ?: L.t("free_none"))
            btnFree.isEnabled = true
        }
    }

    private fun addDialog() {
        val input = EditText(this).apply {
            hint = L.t("add_hint")
            minLines = 4
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip
            ?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()?.let { input.setText(it) }
        AlertDialog.Builder(this).setTitle(L.t("add_title")).setView(input)
            .setPositiveButton(L.t("ok_add")) { _, _ -> importText(input.text.toString()) }
            .setNegativeButton(L.t("cancel"), null).show()
    }

    private fun importText(raw: String) {
        lifecycleScope.launch {
            val text = raw.trim()
            val body = if (text.startsWith("http")) {
                runCatching { withContext(Dispatchers.IO) { URL(text).readText() } }
                    .getOrElse { status.text = L.t("sub_fail"); return@launch }
            } else text
            val parsed = ConfigParser.parseMany(body)
            if (parsed.isEmpty()) { status.text = L.t("no_valid"); return@launch }
            store.links = (store.links + parsed.map { it.link }).distinct()
            reload()
            status.text = L.t("added", parsed.size)
            pingAll()
        }
    }
}
