package app.myvpn

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** تنظیمات: DNS، تونل برای برنامه‌های انتخابی، سرور رایگان خودکار */
class SettingsActivity : AppCompatActivity() {

    private lateinit var store: Store
    private lateinit var dnsInput: EditText
    private lateinit var appsBtn: Button

    private val presets get() = listOf(
        "Cloudflare (1.1.1.1)" to "1.1.1.1,1.0.0.1",
        "Google (8.8.8.8)" to "8.8.8.8,8.8.4.4",
        "Quad9 (9.9.9.9)" to "9.9.9.9,149.112.112.112",
        "AdGuard" to "94.140.14.14,94.140.15.15",
        L.t("dns_custom") to ""
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        L.lang = store.lang
        title = L.t("st_title")
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            layoutDirection = if (L.isFa) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            setBackgroundResource(R.drawable.bg_main)
        }
        fun title(t: String) = TextView(this).apply {
            text = t; textSize = 17f; setPadding(0, pad, 0, pad / 2)
        }
        fun note(t: String) = TextView(this).apply { text = t; textSize = 13f; alpha = 0.7f }

        // ── DNS ──
        root.addView(title("DNS"))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presets.map { it.first })
        dnsInput = EditText(this).apply {
            setText(store.dns)
            hint = L.t("dns_hint"); layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val idx = presets.indexOfFirst { it.second == store.dns }.takeIf { it >= 0 } ?: presets.lastIndex
        spinner.setSelection(idx, false)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (presets[pos].second.isNotEmpty()) dnsInput.setText(presets[pos].second)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spinner)
        root.addView(dnsInput)
        root.addView(note(L.t("dns_note")))

        // ── تونل برنامه‌ها ──
        root.addView(title(L.t("split_title")))
        val group = RadioGroup(this)
        val modes = listOf(
            Store.SPLIT_ALL to L.t("split_all"),
            Store.SPLIT_ONLY to L.t("split_only"),
            Store.SPLIT_EXCEPT to L.t("split_except")
        )
        modes.forEach { (mode, label) ->
            group.addView(RadioButton(this).apply {
                text = label; id = View.generateViewId(); tag = mode
                isChecked = store.splitMode == mode
            })
        }
        group.setOnCheckedChangeListener { g, checkedId ->
            store.splitMode = g.findViewById<RadioButton>(checkedId).tag as Int
        }
        root.addView(group)
        appsBtn = Button(this).apply { setOnClickListener { pickApps() } }
        root.addView(appsBtn)
        updateAppsButton()

        // ── سرور رایگان ──
        root.addView(title(L.t("free_title")))
        root.addView(Switch(this).apply {
            text = L.t("auto_free")
            isChecked = store.autoFree
            setOnCheckedChangeListener { _, on -> store.autoFree = on }
        })
        root.addView(note(L.t("free_note")))

        root.addView(title(""))
        root.addView(note(L.t("apply_note")))

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onPause() {
        store.dns = dnsInput.text.toString().trim().ifEmpty { Store.DEFAULT_DNS }
        super.onPause()
    }

    private fun updateAppsButton() {
        appsBtn.text = L.t("pick_apps", store.splitApps.size)
    }

    private fun pickApps() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .sortedBy { it.second.lowercase() }

        val selected = store.splitApps.toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].first in selected }
        AlertDialog.Builder(this)
            .setTitle(L.t("pick_title"))
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, on ->
                if (on) selected.add(apps[i].first) else selected.remove(apps[i].first)
            }
            .setPositiveButton(L.t("save")) { _, _ ->
                store.splitApps = selected
                updateAppsButton()
            }
            .setNegativeButton(L.t("cancel"), null)
            .show()
    }
}
