package app.myvpn

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

/** یک سرور: نام، لینک اصلی و outbound آمادهٔ Xray */
data class Server(val name: String, val link: String, val outbound: JSONObject) {
    var pingMs: Long = -1
    var free: Boolean = false
}

object ConfigParser {

    /** متن چندخطی (یا base64 اشتراک) را به لیست سرور تبدیل می‌کند */
    fun parseMany(text: String): List<Server> {
        var body = text.trim()
        if (!body.contains("://")) {
            body = runCatching { String(b64(body)) }.getOrDefault(body)
        }
        return body.lines().mapNotNull { parse(it.trim()) }
    }

    fun parse(link: String): Server? = runCatching {
        when {
            link.startsWith("vless://") -> vless(link)
            link.startsWith("vmess://") -> vmess(link)
            link.startsWith("trojan://") -> trojan(link)
            link.startsWith("ss://") -> shadowsocks(link)
            else -> null
        }
    }.getOrNull()

    /** base64 استاندارد و url-safe، با یا بدون padding */
    private fun b64(s: String): ByteArray {
        var t = s.trim().replace('-', '+').replace('_', '/')
        while (t.length % 4 != 0) t += "="
        return Base64.decode(t, Base64.DEFAULT)
    }

    private fun stream(
        type: String, security: String, sni: String?, fp: String?, host: String?, path: String?,
        pbk: String?, sid: String?, alpn: String?, serviceName: String?, spx: String?
    ): JSONObject {
        val s = JSONObject().put("network", if (type == "http") "h2" else type).put("security", security)
        when (security) {
            "tls" -> s.put("tlsSettings", JSONObject().apply {
                if (!sni.isNullOrEmpty()) put("serverName", sni)
                if (!fp.isNullOrEmpty()) put("fingerprint", fp)
                if (!alpn.isNullOrEmpty()) put("alpn", JSONArray(alpn.split(",")))
            })
            "reality" -> s.put("realitySettings", JSONObject().apply {
                put("serverName", sni ?: "")
                put("fingerprint", fp ?: "chrome")
                put("publicKey", pbk ?: "")
                put("shortId", sid ?: "")
                put("spiderX", spx ?: "")
            })
        }
        when (type) {
            "ws" -> s.put("wsSettings", JSONObject().apply {
                put("path", path ?: "/")
                if (!host.isNullOrEmpty()) put("headers", JSONObject().put("Host", host))
            })
            "grpc" -> s.put("grpcSettings", JSONObject().put("serviceName", serviceName ?: ""))
            "httpupgrade" -> s.put("httpupgradeSettings", JSONObject().apply {
                put("path", path ?: "/"); if (!host.isNullOrEmpty()) put("host", host)
            })
            "xhttp", "splithttp" -> s.put("xhttpSettings", JSONObject().apply {
                put("path", path ?: "/"); if (!host.isNullOrEmpty()) put("host", host)
            })
        }
        return s
    }

    private fun vless(link: String): Server {
        val u = Uri.parse(link)
        val q = { k: String -> u.getQueryParameter(k) }
        val out = JSONObject()
            .put("tag", "proxy").put("protocol", "vless")
            .put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject()
                .put("address", u.host).put("port", u.port)
                .put("users", JSONArray().put(JSONObject()
                    .put("id", u.userInfo).put("encryption", q("encryption") ?: "none")
                    .apply { q("flow")?.takeIf { it.isNotEmpty() }?.let { put("flow", it) } })))))
            .put("streamSettings", stream(
                q("type") ?: "tcp", q("security") ?: "none", q("sni"), q("fp"), q("host"),
                q("path"), q("pbk"), q("sid"), q("alpn"), q("serviceName"), q("spx")))
        return Server(u.fragment ?: "${u.host}:${u.port}", link, out)
    }

    private fun vmess(link: String): Server {
        val j = JSONObject(String(b64(link.removePrefix("vmess://"))))
        val net = j.optString("net", "tcp")
        val tls = j.optString("tls", "")
        val out = JSONObject()
            .put("tag", "proxy").put("protocol", "vmess")
            .put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject()
                .put("address", j.getString("add")).put("port", j.get("port").toString().toInt())
                .put("users", JSONArray().put(JSONObject()
                    .put("id", j.getString("id")).put("alterId", j.optString("aid", "0").toInt())
                    .put("security", j.optString("scy", "auto")))))))
            .put("streamSettings", stream(
                net, if (tls == "tls") "tls" else "none", j.optString("sni").ifEmpty { j.optString("host") },
                j.optString("fp"), j.optString("host"), j.optString("path"), null, null,
                j.optString("alpn"), j.optString("path"), null))
        return Server(j.optString("ps", j.getString("add")), link, out)
    }

    private fun trojan(link: String): Server {
        val u = Uri.parse(link)
        val q = { k: String -> u.getQueryParameter(k) }
        val out = JSONObject()
            .put("tag", "proxy").put("protocol", "trojan")
            .put("settings", JSONObject().put("servers", JSONArray().put(JSONObject()
                .put("address", u.host).put("port", u.port).put("password", u.userInfo))))
            .put("streamSettings", stream(
                q("type") ?: "tcp", q("security") ?: "tls", q("sni"), q("fp"), q("host"),
                q("path"), q("pbk"), q("sid"), q("alpn"), q("serviceName"), q("spx")))
        return Server(u.fragment ?: "${u.host}:${u.port}", link, out)
    }

    private fun shadowsocks(link: String): Server {
        val noScheme = link.removePrefix("ss://")
        val name = noScheme.substringAfter('#', "").let { Uri.decode(it) }
        val main = noScheme.substringBefore('#').substringBefore('?')
        val method: String; val pass: String; val host: String; val port: Int
        if (main.contains('@')) {
            val cred = main.substringBefore('@')
            val decoded = runCatching { String(b64(cred)) }.getOrDefault(cred)
            method = decoded.substringBefore(':'); pass = decoded.substringAfter(':')
            host = main.substringAfter('@').substringBeforeLast(':')
            port = main.substringAfterLast(':').toInt()
        } else {
            val decoded = String(b64(main))
            method = decoded.substringBefore(':')
            pass = decoded.substringAfter(':').substringBeforeLast('@')
            host = decoded.substringAfterLast('@').substringBeforeLast(':')
            port = decoded.substringAfterLast(':').toInt()
        }
        val out = JSONObject()
            .put("tag", "proxy").put("protocol", "shadowsocks")
            .put("settings", JSONObject().put("servers", JSONArray().put(JSONObject()
                .put("address", host).put("port", port).put("method", method).put("password", pass))))
        return Server(name.ifEmpty { "$host:$port" }, link, out)
    }

    /**
     * کانفیگ کامل برای اتصال (با ورودی TUN).
     * [pool] شامل سرور اصلی (اول) و چند سرور جایگزینِ از قبل تست‌شده است.
     * خود Xray با observatory + balancer(leastPing) هر ۱۰ ثانیه کیفیت همه را می‌سنجد و
     * اگر سرور فعال افت کرد، بدون قطع اتصال‌ها به بهترین جایگزین می‌رود.
     */
    fun fullConfig(pool: List<Server>, dns: List<String>): String {
        val outs = JSONArray()
        pool.forEachIndexed { i, s ->
            outs.put(JSONObject(s.outbound.toString()).put("tag", "proxy-$i"))
        }
        outs.put(JSONObject().put("tag", "direct").put("protocol", "freedom"))

        val rules = JSONArray()
            // شبکهٔ محلی مستقیم
            .put(JSONObject().put("type", "field")
                .put("ip", JSONArray(listOf("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8")))
                .put("outboundTag", "direct"))
            // بقیه از طریق balancer
            .put(JSONObject().put("type", "field").put("network", "tcp,udp").put("balancerTag", "bal"))

        val balancer = JSONObject().put("tag", "bal")
            .put("selector", JSONArray().put("proxy-"))
            .put("strategy", JSONObject().put("type", "leastPing"))
            .put("fallbackTag", "proxy-0")

        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put("dns", JSONObject().put("servers", JSONArray(dns)))
            .put("inbounds", JSONArray().put(JSONObject()
                .put("tag", "tun-in").put("protocol", "tun")
                .put("settings", JSONObject().put("name", "xray0").put("MTU", 1500))
                .put("sniffing", JSONObject().put("enabled", true)
                    .put("destOverride", JSONArray().put("http").put("tls")))))
            .put("outbounds", outs)
            .put("observatory", JSONObject()
                .put("subjectSelector", JSONArray().put("proxy-"))
                .put("probeUrl", "https://www.gstatic.com/generate_204")
                .put("probeInterval", "10s"))
            .put("routing", JSONObject().put("domainStrategy", "AsIs")
                .put("rules", rules).put("balancers", JSONArray().put(balancer)))
            .toString()
    }

    /** کانفیگ سبک فقط برای تست تأخیر */
    fun probeConfig(server: Server): String = JSONObject()
        .put("log", JSONObject().put("loglevel", "none"))
        .put("outbounds", JSONArray().put(server.outbound))
        .toString()
}
