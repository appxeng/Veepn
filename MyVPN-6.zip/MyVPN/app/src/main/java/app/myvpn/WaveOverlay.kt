package app.myvpn

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.hypot
import kotlin.math.sin

/** موج وای‌فای از چهار طرف صفحه به سمت مرکز (با چهار بار زدن روی «by hasan.d») */
class WaveOverlay @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {

    private val dp = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = -1f
    private var anim: ValueAnimator? = null
    private val rect = RectF()

    fun play() {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3200
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(an: android.animation.Animator) { t = -1f; invalidate() }
            })
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        if (t < 0f) return
        val w = width.toFloat(); val h = height.toFloat()
        val env = sin(Math.PI * t).toFloat().coerceIn(0f, 1f)          // ظاهر و محو شدن کلی
        // هر طرف: مبدأ روی لبه، زاویهٔ مرکزِ کمان به سمت داخل
        data class Side(val ox: Float, val oy: Float, val center: Float, val reach: Float)
        val sides = listOf(
            Side(w / 2, 0f, 90f, h / 2),        // بالا → پایین
            Side(w / 2, h, 270f, h / 2),        // پایین → بالا
            Side(0f, h / 2, 0f, w / 2),         // چپ → راست
            Side(w, h / 2, 180f, w / 2)         // راست → چپ
        )
        val maxR = hypot(w, h) * 0.42f
        for (s in sides) {
            // آیکن نقطهٔ وای‌فای روی لبه
            dot.color = ((env * 255).toInt() shl 24) or 0x1596AB
            cv.drawCircle(s.ox, s.oy, 7 * dp, dot)
            for (k in 0 until 4) {                                       // چهار موج پشت‌سرهم
                val ph = ((t * 1.6f) - k * 0.22f)
                if (ph <= 0f || ph >= 1f) continue
                val r = 14 * dp + ph * maxR
                val alpha = ((1f - ph) * env * 235).toInt().coerceIn(0, 255)
                p.strokeWidth = (7 - 4 * ph) * dp
                p.color = (alpha shl 24) or (if (k % 2 == 0) 0x2BC0D3 else 0x1596AB)
                rect.set(s.ox - r, s.oy - r, s.ox + r, s.oy + r)
                cv.drawArc(rect, s.center - 46f, 92f, false, p)
            }
        }
        // نشانهٔ برخورد در مرکز
        val c = ((t - 0.35f) / 0.4f).coerceIn(0f, 1f)
        if (c > 0f && c < 1f) {
            p.strokeWidth = 4 * dp
            p.color = (((1f - c) * 200).toInt() shl 24) or 0xF2B544
            cv.drawCircle(w / 2, h / 2, 20 * dp + c * 70 * dp, p)
        }
    }
}
