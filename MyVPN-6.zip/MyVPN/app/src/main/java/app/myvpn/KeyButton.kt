package app.myvpn

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.animation.OvershootInterpolator
import androidx.appcompat.widget.AppCompatTextView

/**
 * دکمهٔ شیشه‌ای سفید شبیه کلید کیبورد: رویهٔ شیشه‌ای روی یک پایه؛ با لمس واقعاً پایین می‌رود.
 * primary = دکمهٔ اصلی (فیروزه‌ای)، danger = حالت قطع اتصال (قرمز)
 */
class KeyButton @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : AppCompatTextView(c, a) {

    var primary = false; set(v) { field = v; applyColors(); invalidate() }
    var danger = false; set(v) { field = v; applyColors(); invalidate() }

    private val dp = resources.displayMetrics.density
    private val depth = 7 * dp
    private val radius = 18 * dp
    private var press = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        if (a != null) {
            val t = c.obtainStyledAttributes(a, R.styleable.KeyButton)
            primary = t.getBoolean(R.styleable.KeyButton_primary, false)
            danger = t.getBoolean(R.styleable.KeyButton_danger, false)
            t.recycle()
        }
        gravity = Gravity.CENTER
        isClickable = true
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setPadding((10 * dp).toInt(), (6 * dp).toInt(), (10 * dp).toInt(), (6 * dp).toInt() + depth.toInt())
        applyColors()
    }

    private fun applyColors() {
        setTextColor(if (primary || danger) Color.WHITE else 0xFF0B3B4A.toInt())
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = if (enabled) 1f else 0.55f
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!isEnabled) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animatePress(1f, 70, null)
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animatePress(0f, 160, OvershootInterpolator(2.2f))
        }
        return super.onTouchEvent(e)
    }

    private fun animatePress(to: Float, ms: Long, ip: android.animation.TimeInterpolator?) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(press, to).apply {
            duration = ms
            ip?.let { interpolator = it }
            addUpdateListener { press = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val faceH = h - depth
        val dy = press * depth * 0.92f

        val side: Int; val top: Int; val bot: Int; val border: Int
        when {
            danger -> { side = 0xFF6E1C1B.toInt(); top = 0xFFE5655F.toInt(); bot = 0xFFB3322F.toInt(); border = 0xCCFFFFFF.toInt() }
            primary -> { side = 0xFF0A4A5E.toInt(); top = 0xFF48D6E6.toInt(); bot = 0xFF1596AB.toInt(); border = 0xCCFFFFFF.toInt() }
            else -> { side = 0xFF9ACFD9.toInt(); top = 0xFFFFFFFF.toInt(); bot = 0xFFE4F5F8.toInt(); border = 0xFFFFFFFF.toInt() }
        }

        // سایهٔ نرم زیر کلید
        p.style = Paint.Style.FILL
        p.color = 0x330B5A6E
        rect.set(2 * dp, depth + 2 * dp, w - 2 * dp, h)
        cv.drawRoundRect(rect, radius, radius, p)

        // پایهٔ کلید (دیوارهٔ کنار)
        p.color = side
        rect.set(0f, depth, w, h - 1.5f * dp)
        cv.drawRoundRect(rect, radius, radius, p)

        // رویهٔ شیشه‌ای
        rect.set(0f, dy, w, faceH + dy)
        p.shader = LinearGradient(0f, dy, 0f, faceH + dy, top, bot, Shader.TileMode.CLAMP)
        cv.drawRoundRect(rect, radius, radius, p)
        p.shader = null

        // براقیِ شیشه (نیمهٔ بالا)
        val gl = RectF(4 * dp, dy + 3 * dp, w - 4 * dp, dy + faceH * 0.52f)
        p.shader = LinearGradient(0f, gl.top, 0f, gl.bottom,
            if (primary || danger) 0x77FFFFFF else 0xDDFFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
        cv.drawRoundRect(gl, radius - 3 * dp, radius - 3 * dp, p)
        p.shader = null

        // لبهٔ شیشه
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * dp
        p.color = border
        rect.set(0.8f * dp, dy + 0.8f * dp, w - 0.8f * dp, faceH + dy - 0.8f * dp)
        cv.drawRoundRect(rect, radius, radius, p)
        if (!primary && !danger) {
            p.strokeWidth = 1f * dp; p.color = 0x401596AB
            rect.inset(1.6f * dp, 1.6f * dp)
            cv.drawRoundRect(rect, radius - 2 * dp, radius - 2 * dp, p)
        }

        // متن: وسط رویه، و همراه آن پایین می‌رود
        cv.save()
        cv.translate(0f, dy - depth / 2f)
        super.onDraw(cv)
        cv.restore()
    }
}
