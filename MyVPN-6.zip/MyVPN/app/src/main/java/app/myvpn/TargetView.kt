package app.myvpn

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.*

/**
 * سیبل از روبرو + تیر سه‌بعدی (پرسپکتیو).
 * وصل شد: تیر وسط خال سیبل می‌نشیند و عقاب روی سیبل می‌نشیند.
 * وصل نشد: تیر از کنار سیبل رد می‌شود و در دوردست محو می‌شود؛ با تلاش بعدی تیر تازه‌ای می‌آید.
 */
class TargetView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {

    enum class S { IDLE, CONNECTING, CONNECTED, MISSED }

    private var state = S.IDLE
    private var u = -1f            // پیشرفت پرواز (۰ شروع … ۱ برخورد با سیبل … بیشتر = رد شده)
    private var miss = 0f          // ۰ = نشانه‌گیری به مرکز … ۱ = منحرف به کنار سیبل
    private var fade = 1f
    private var pct = 0f           // درصد نمایشی (۰..۱)
    private var eagle = 0f
    private var ripple = 0f
    private val anims = mutableListOf<ValueAnimator>()

    private val dp = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val head: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.eagle_head)

    // مختصات سه‌بعدی (واحد = شعاع سیبل): دوربین در z = -F، سیبل در z = 0
    private val F = 3.2f
    private val S0 = floatArrayOf(-0.55f, 0.5f, -1.7f)
    private val EH = floatArrayOf(0f, 0f, 0f)
    private val EM = floatArrayOf(1.35f, -0.6f, 0f)

    private fun go(a: ValueAnimator): ValueAnimator { anims += a; a.start(); return a }
    private fun cancelAll() { anims.forEach { it.removeAllListeners(); it.cancel() }; anims.clear() }

    fun setState(s: S) {
        if (s == state) return
        val prev = state
        state = s
        cancelAll()
        when (s) {
            S.IDLE -> {
                u = -1f; miss = 0f; fade = 1f; eagle = 0f; ripple = 0f
                go(ValueAnimator.ofFloat(pct, 0f).apply {
                    duration = 350; addUpdateListener { pct = it.animatedValue as Float; invalidate() }
                })
            }
            S.CONNECTING -> {                                  // تیر تازه از اول می‌آید
                u = 0f; miss = 0f; fade = 1f; eagle = 0f; ripple = 0f; pct = 0f
                go(ValueAnimator.ofFloat(0f, 0.92f).apply {
                    duration = 7000; interpolator = DecelerateInterpolator(1.5f)
                    addUpdateListener { u = it.animatedValue as Float; pct = u; invalidate() }
                })
            }
            S.CONNECTED -> {
                if (prev == S.IDLE || prev == S.MISSED) { u = max(u, 0.55f); fade = 1f; miss = 0f }
                val from = u
                go(ValueAnimator.ofFloat(from, 1f).apply {
                    duration = 380; interpolator = LinearInterpolator()
                    addUpdateListener { u = it.animatedValue as Float; pct = u; invalidate() }
                    addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(an: Animator) { hit() } })
                })
            }
            S.MISSED -> {
                val u0 = max(u, 0.2f); val p0 = pct
                go(ValueAnimator.ofFloat(0f, 1f).apply {            // انحراف به کنار
                    duration = 450; addUpdateListener { miss = it.animatedValue as Float; invalidate() }
                })
                go(ValueAnimator.ofFloat(u0, 2.2f).apply {          // ادامهٔ پرواز و دور شدن
                    duration = 1700; interpolator = LinearInterpolator()
                    addUpdateListener {
                        u = it.animatedValue as Float
                        fade = if (u > 1.4f) (1f - (u - 1.4f) / 0.8f).coerceIn(0f, 1f) else 1f
                        pct = p0 * (1f - (u - u0) / (2.2f - u0)).coerceIn(0f, 1f)
                        invalidate()
                    }
                    addListener(object : AnimatorListenerAdapter() {
                        override fun onAnimationEnd(an: Animator) { u = -1f; pct = 0f; invalidate() }
                    })
                })
            }
        }
        invalidate()
    }

    /** بدون انیمیشن (هنگام برگشتن به برنامه) */
    fun snap(s: S) {
        cancelAll(); state = s
        when (s) {
            S.CONNECTED -> { u = 1f; pct = 1f; eagle = 1f; ripple = 0f; miss = 0f; fade = 1f }
            S.CONNECTING -> { u = 0.5f; pct = 0.5f; eagle = 0f; miss = 0f; fade = 1f
                go(ValueAnimator.ofFloat(0.5f, 0.92f).apply {
                    duration = 5000; interpolator = DecelerateInterpolator(1.5f)
                    addUpdateListener { u = it.animatedValue as Float; pct = u; invalidate() } }) }
            else -> { u = -1f; pct = 0f; eagle = 0f; ripple = 0f; miss = 0f; fade = 1f }
        }
        invalidate()
    }

    private fun hit() {
        go(ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900; addUpdateListener { ripple = it.animatedValue as Float; invalidate() }
        })
        go(ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 650; startDelay = 150; interpolator = OvershootInterpolator(2f)
            addUpdateListener { eagle = it.animatedValue as Float; invalidate() }
        })
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = min(MeasureSpec.getSize(w), (320 * dp).toInt())
        setMeasuredDimension(s, (s * 1.08f).toInt())
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val R = w * 0.335f
        val cy = height * 0.5f + 4 * dp
        val rr = R + 13 * dp

        // هالهٔ شیشه‌ای
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, R * 1.3f, intArrayOf(0x552BC0D3, 0x002BC0D3), null, Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, R * 1.3f, p); p.shader = null

        // سیبل از روبرو
        val cols = intArrayOf(0xEEFFFFFF.toInt(), 0xEEBFE9EF.toInt(), 0xEEFFFFFF.toInt(), 0xEE8ED6E1.toInt(), 0xEEFFFFFF.toInt())
        val rs = floatArrayOf(1f, 0.8f, 0.6f, 0.4f, 0.2f)
        for (i in rs.indices) { p.color = cols[i]; cv.drawCircle(cx, cy, R * rs[i], p) }
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.4f * dp; p.color = 0xFF1596AB.toInt()
        for (r in rs) cv.drawCircle(cx, cy, R * r, p)
        p.style = Paint.Style.FILL; p.color = 0xFFF2B544.toInt(); cv.drawCircle(cx, cy, R * 0.09f, p)

        // حلقهٔ درصد
        p.style = Paint.Style.STROKE; p.strokeWidth = 7 * dp; p.strokeCap = Paint.Cap.ROUND
        p.color = 0x330B5A6E
        val box = RectF(cx - rr, cy - rr, cx + rr, cy + rr)
        cv.drawArc(box, 0f, 360f, false, p)
        p.color = if (state == S.CONNECTED) 0xFF1596AB.toInt() else 0xFF2BC0D3.toInt()
        if (pct > 0.003f) cv.drawArc(box, -90f, 360f * pct, false, p)

        // موج برخورد
        if (ripple in 0.01f..0.99f) {
            p.strokeWidth = 3 * dp; p.color = (((1f - ripple) * 180).toInt() shl 24) or 0x1596AB
            cv.drawCircle(cx, cy, R * (0.1f + ripple * 0.9f), p)
        }

        // تیر
        if (u >= 0f && fade > 0.01f) drawArrow(cv, cx, cy, R)

        // عقاب نشسته بالای سیبل
        if (eagle > 0.01f) {
            val er = R * 0.30f * eagle
            val ex = cx; val ey = cy - rr - er * 0.35f
            p.style = Paint.Style.FILL; p.color = 0x55000000; cv.drawCircle(ex, ey + 4 * dp, er, p)
            val sv = cv.save()
            path.reset(); path.addCircle(ex, ey, er, Path.Direction.CW)
            cv.clipPath(path)
            cv.drawBitmap(head, null, RectF(ex - er, ey - er, ex + er, ey + er), p)
            cv.restoreToCount(sv)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * dp; p.color = 0xFFFFFFFF.toInt()
            cv.drawCircle(ex, ey, er, p)
        }

        // درصد
        p.style = Paint.Style.FILL; p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
        p.color = if (state == S.CONNECTED) 0xFF0B5A6E.toInt() else 0xFF0B3B4A.toInt()
        p.textSize = 38 * dp
        cv.drawText(L.digits("${(pct * 100).roundToInt()}%"), cx, height - 8 * dp, p)
    }

    // ───────────── تیر سه‌بعدی ─────────────

    private fun proj(x: Float, y: Float, z: Float, cx: Float, cy: Float, R: Float, out: FloatArray) {
        val k = F / max(0.2f, F + z)
        out[0] = cx + x * k * R; out[1] = cy + y * k * R; out[2] = k
    }

    private fun poly(cv: Canvas, color: Int, vararg pts: FloatArray) {
        path.reset()
        pts.forEachIndexed { i, q -> if (i == 0) path.moveTo(q[0], q[1]) else path.lineTo(q[0], q[1]) }
        path.close()
        p.style = Paint.Style.FILL
        p.color = (color and 0x00FFFFFF) or ((((color ushr 24) * fade).toInt().coerceIn(0, 255)) shl 24)
        cv.drawPath(path, p)
    }

    private fun drawArrow(cv: Canvas, cx: Float, cy: Float, R: Float) {
        // نقطهٔ هدف: وسط سیبل یا کنار آن
        val ex = EH[0] + (EM[0] - EH[0]) * miss
        val ey = EH[1] + (EM[1] - EH[1]) * miss
        val dx = ex - S0[0]; val dy = ey - S0[1]; val dz = 0f - S0[2]
        val dl = sqrt(dx * dx + dy * dy + dz * dz)
        val d = floatArrayOf(dx / dl, dy / dl, dz / dl)
        val T = floatArrayOf(S0[0] + dx * u, S0[1] + dy * u, S0[2] + dz * u)
        val len = 1.1f
        val tail = floatArrayOf(T[0] - d[0] * len, T[1] - d[1] * len, T[2] - d[2] * len)

        val a = FloatArray(3); val t = FloatArray(3)
        proj(tail[0], tail[1], tail[2], cx, cy, R, a)
        proj(T[0], T[1], T[2], cx, cy, R, t)

        // میله
        var sx = t[0] - a[0]; var sy = t[1] - a[1]
        val sl = max(0.001f, hypot(sx, sy)); sx /= sl; sy /= sl
        val nx = -sy; val ny = sx
        val wa = 0.032f * R * a[2]; val wt = 0.032f * R * t[2]
        poly(cv, 0xFF0B3B4A.toInt(),
            floatArrayOf(a[0] + nx * wa, a[1] + ny * wa), floatArrayOf(t[0] + nx * wt, t[1] + ny * wt),
            floatArrayOf(t[0] - nx * wt, t[1] - ny * wt), floatArrayOf(a[0] - nx * wa, a[1] - ny * wa))

        // پرهای ته تیر (سه پر در فضای سه‌بعدی)
        val up = if (abs(d[1]) > 0.9f) floatArrayOf(1f, 0f, 0f) else floatArrayOf(0f, 1f, 0f)
        var n1 = cross(d, up); val l1 = sqrt(n1[0] * n1[0] + n1[1] * n1[1] + n1[2] * n1[2])
        n1 = floatArrayOf(n1[0] / l1, n1[1] / l1, n1[2] / l1)
        val n2 = cross(d, n1)
        val vcols = intArrayOf(0xFF1596AB.toInt(), 0xFF2BC0D3.toInt(), 0xFF0E7D90.toInt())
        val vanes = (0 until 3).map { i ->
            val th = i * 2f * PI.toFloat() / 3f + 0.5f
            val r = floatArrayOf(n1[0] * cos(th) + n2[0] * sin(th), n1[1] * cos(th) + n2[1] * sin(th), n1[2] * cos(th) + n2[2] * sin(th))
            fun pt(base: Float, off: Float): FloatArray {
                val o = FloatArray(3)
                proj(tail[0] + d[0] * base + r[0] * off, tail[1] + d[1] * base + r[1] * off, tail[2] + d[2] * base + r[2] * off, cx, cy, R, o)
                return o
            }
            Triple(r[2], vcols[i], listOf(pt(0f, 0f), pt(0f, 0.22f), pt(0.42f, 0.10f), pt(0.42f, 0f)))
        }.sortedByDescending { it.first }
        vanes.forEach { poly(cv, it.second, *it.third.toTypedArray()) }

        // نوک طلایی
        val hb = FloatArray(3)
        proj(T[0] - d[0] * 0.2f, T[1] - d[1] * 0.2f, T[2] - d[2] * 0.2f, cx, cy, R, hb)
        var hx = t[0] - hb[0]; var hy = t[1] - hb[1]
        val hl = max(0.001f, hypot(hx, hy)); hx /= hl; hy /= hl
        val hw = 0.075f * R * hb[2]
        poly(cv, 0xFFF2B544.toInt(),
            floatArrayOf(t[0], t[1]), floatArrayOf(hb[0] - hy * hw, hb[1] + hx * hw), floatArrayOf(hb[0] + hy * hw, hb[1] - hx * hw))
    }

    private fun cross(a: FloatArray, b: FloatArray) = floatArrayOf(
        a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
}
