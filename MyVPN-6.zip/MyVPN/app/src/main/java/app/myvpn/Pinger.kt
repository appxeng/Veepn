package app.myvpn

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import libv2ray.Libv2ray

/** تست تأخیر واقعی (از مسیر خود پروکسی) و مرتب‌سازی سرورها */
object Pinger {
    const val TEST_URL = "https://www.gstatic.com/generate_204"

    /** یک تست؛ -1 یعنی ناموفق */
    @Volatile var lastError: Throwable? = null

    fun measure(s: Server): Long =
        runCatching { Libv2ray.measureOutboundDelay(ConfigParser.probeConfig(s), TEST_URL) }
            .onFailure { lastError = it }
            .getOrDefault(-1L)

    /** خطای «هسته روی این پردازنده نیست» (کتابخانهٔ native بارگذاری نشده) */
    fun nativeProblem(): String? = lastError?.takeIf {
        it is UnsatisfiedLinkError || it is NoClassDefFoundError || it is ExceptionInInitializerError
    }?.let { (it.message ?: it.javaClass.simpleName).take(120) }

    /** سرورها را موازی تست می‌کند؛ نتیجه در server.pingMs (-1 = ناموفق) */
    suspend fun testAll(
        servers: List<Server>,
        concurrency: Int = 8,
        onEach: ((Server) -> Unit)? = null
    ) = coroutineScope {
        val gate = Semaphore(concurrency)
        servers.map { s ->
            async(Dispatchers.IO) {
                gate.withPermit {
                    s.pingMs = measure(s)
                    onEach?.let { cb -> withContext(Dispatchers.Main) { cb(s) } }
                    Unit
                }
            }
        }.awaitAll()
    }

    /** سالم‌ها از کم‌پینگ به پرپینگ، بعد ناموفق‌ها */
    fun sorted(servers: List<Server>): List<Server> =
        servers.filter { it.pingMs > 0 }.sortedBy { it.pingMs } + servers.filter { it.pingMs <= 0 }

    fun best(servers: List<Server>): Server? = servers.filter { it.pingMs > 0 }.minByOrNull { it.pingMs }
}
